<?php
require_once __DIR__ '../models/AntecedenteAcademico.php';
require_once __DIR__ '../config/db.php';

header("Content-Type: application/json");

$database = new Database();
$db = $database->getConnection();
$academico = new AntecedenteAcademico($db);

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (
            !$data ||
            !isset($data['candidato_id'], $data['institucion'], $data['titulo_obtenido'], $data['anio_ingreso'], $data['anio_egreso'])
        ) {
            http_response_code(400);
            echo json_encode(["message" => "Datos incompletos para antecedente académico."]);
            break;
        }
        echo json_encode($academico->crear($data));
        break;

    default:
        http_response_code(405);
        echo json_encode(["message" => "Método no permitido"]);
}
?>
