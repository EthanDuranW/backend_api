<?php
require_once(__DIR__ . '/../models/AntecedenteLaboral.php');

require_once(__DIR__ . '/../config/db.php');


header("Content-Type: application/json");

$database = new Database();
$db = $database->getConnection();
$laboral = new AntecedenteLaboral($db);

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (
            !$data ||
            !isset($data['candidato_id'], $data['empresa'], $data['cargo'], $data['funciones'], $data['fecha_inicio'], $data['fecha_termino'])
        ) {
            http_response_code(400);
            echo json_encode(["message" => "Datos incompletos para antecedente laboral."]);
            break;
        }
        echo json_encode($laboral->crear($data));
        break;

    default:
        http_response_code(405);
        echo json_encode(["message" => "Método no permitido"]);
}
?>
