<?php
require_once __DIR__ . '/../models/Postulacion.php';
require_once __DIR__ . '/../config/db.php';

header("Content-Type: application/json");

$database = new Database();
$db = $database->getConnection();
$postulacion = new Postulacion($db);

$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['REQUEST_URI'], '/'));

switch ($method) {
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || !isset($data['candidato_id'], $data['oferta_laboral_id'])) {
            http_response_code(400);
            echo json_encode(["message" => "Datos incompletos para postulación."]);
            break;
        }
        echo json_encode($postulacion->crearPostulacion($data));
        break;

    case 'PATCH':
        if (isset($request[2])) {
            $data = json_decode(file_get_contents("php://input"), true);
            if (!$data || !isset($data['estado_postulacion'], $data['comentario'])) {
                http_response_code(400);
                echo json_encode(["message" => "Datos incompletos para actualizar estado."]);
                break;
            }
            echo json_encode($postulacion->actualizarEstado($request[2], $data));
        } else {
            http_response_code(400);
            echo json_encode(["message" => "ID de postulación no proporcionado."]);
        }
        break;

    case 'GET':
        if (isset($_GET['oferta_id'])) {
            echo json_encode($postulacion->obtenerPostulacionesPorOferta($_GET['oferta_id']));
        } elseif (isset($request[2])) {
            echo json_encode($postulacion->verEstado($request[2]));
        } else {
            http_response_code(400);
            echo json_encode(["message" => "ID no proporcionado para consultar."]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["message" => "Método no permitido"]);
}
?>
