<?php
class AntecedenteLaboral {
    private $conn;
    private $tabla = "AntecedenteLaboral";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function crear($data) {
        $query = "INSERT INTO " . $this->tabla . " 
                  (candidato_id, empresa, cargo, funciones, fecha_inicio, fecha_termino)
                  VALUES 
                  (:candidato_id, :empresa, :cargo, :funciones, :fecha_inicio, :fecha_termino)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':candidato_id', $data['candidato_id']);
        $stmt->bindParam(':empresa', $data['empresa']);
        $stmt->bindParam(':cargo', $data['cargo']);
        $stmt->bindParam(':funciones', $data['funciones']);
        $stmt->bindParam(':fecha_inicio', $data['fecha_inicio']);
        $stmt->bindParam(':fecha_termino', $data['fecha_termino']);
        if ($stmt->execute()) {
            return ["message" => "Antecedente laboral registrado"];
        }
        return ["message" => "Error al registrar antecedente laboral"];
    }
}
?>
