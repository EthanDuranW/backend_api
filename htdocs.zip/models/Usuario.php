<?php
class Usuario {
    private $conn;
    private $tabla = "Usuario";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT id, nombre, apellido, email, rol, estado FROM " . $this->tabla;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT id, nombre, apellido, email, rol, estado FROM " . $this->tabla . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        try {
            // Validar que todos los campos necesarios estén presentes
            $campos = ['nombre', 'apellido', 'email', 'clave', 'fecha_nacimiento', 'telefono', 'direccion', 'rol'];
            #var_dump($data);
            #exit;

            foreach ($campos as $campo) {
                if (!isset($data[$campo])) {
                    return ["error" => "Falta el campo: $campo"];
                }
            }
    
            // Preparar consulta
            $query = "INSERT INTO " . $this->tabla . " 
                (nombre, apellido, email, clave, fecha_nacimiento, telefono, direccion, rol)
                VALUES 
                (:nombre, :apellido, :email, :clave, :fecha_nacimiento, :telefono, :direccion, :rol)";
            
            $stmt = $this->conn->prepare($query);
    
            // Asignar valores
            $stmt->bindValue(':nombre', $data['nombre']);
            $stmt->bindValue(':apellido', $data['apellido']);
            $stmt->bindValue(':email', $data['email']);
            $stmt->bindValue(':clave', $data['clave']);
            $stmt->bindValue(':fecha_nacimiento', $data['fecha_nacimiento']);
            $stmt->bindValue(':telefono', $data['telefono']);
            $stmt->bindValue(':direccion', $data['direccion']);
            $stmt->bindValue(':rol', $data['rol']);
    
            // Ejecutar y responder
            if ($stmt->execute()) {
                return ["message" => "Usuario registrado con éxito"];
            } else {
                return ["error" => "Error al ejecutar la consulta"];
            }
        } catch (PDOException $e) {
            return ["error" => $e->getMessage()];
        }
    }
    
    

    #public function create($data) {
    #    $query = "INSERT INTO " . $this->tabla . " 
    #        (nombre, apellido, email, clave, fecha_nacimiento, telefono, direccion, rol)
    #        VALUES 
    #        (:nombre, :apellido, :email, :clave, :fecha_nacimiento, :telefono, :direccion, :rol)";
    #    $stmt = $this->conn->prepare($query);
    #    $stmt->bindParam(':nombre', $data['nombre']);
    #    $stmt->bindParam(':apellido', $data['apellido']);
    #    $stmt->bindParam(':email', $data['email']);
    #    $stmt->bindParam(':clave', $data['clave']);
    #    $stmt->bindParam(':fecha_nacimiento', $data['fecha_nacimiento']);
    #    $stmt->bindParam(':telefono', $data['telefono']);
    #    $stmt->bindParam(':direccion', $data['direccion']);
    #    $stmt->bindParam(':rol', $data['rol']);
    #    if ($stmt->execute()) {
    #        return ["message" => "Usuario registrado con éxito"];
    #    }
    #    return ["message" => "Error al registrar usuario"];
    #}

    public function update($id, $data) {
        $query = "UPDATE " . $this->tabla . " 
                  SET nombre = :nombre, apellido = :apellido, email = :email, telefono = :telefono, direccion = :direccion 
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nombre', $data['nombre']);
        $stmt->bindParam(':apellido', $data['apellido']);
        $stmt->bindParam(':email', $data['email']);
        $stmt->bindParam(':telefono', $data['telefono']);
        $stmt->bindParam(':direccion', $data['direccion']);
        $stmt->bindParam(':id', $id);
        if ($stmt->execute()) {
            return ["message" => "Usuario actualizado"];
        }
        return ["message" => "Error al actualizar usuario"];
    }
}
?>
