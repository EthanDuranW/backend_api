<?php
class Oferta {
    private $conn;
    private $table = "OfertaLaboral"; // Nombre correcto de la tabla

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " WHERE estado = 'Vigente'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ? LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table . " 
                  (titulo, descripcion, ubicacion, salario, tipo_contrato, fecha_cierre, reclutador_id)
                  VALUES 
                  (:titulo, :descripcion, :ubicacion, :salario, :tipo_contrato, :fecha_cierre, :reclutador_id)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':titulo', $data['titulo']);
        $stmt->bindParam(':descripcion', $data['descripcion']);
        $stmt->bindParam(':ubicacion', $data['ubicacion']);
        $stmt->bindParam(':salario', $data['salario']);
        $stmt->bindParam(':tipo_contrato', $data['tipo_contrato']);
        $stmt->bindParam(':fecha_cierre', $data['fecha_cierre']);
        $stmt->bindParam(':reclutador_id', $data['reclutador_id']);
        if ($stmt->execute()) {
            return ["message" => "Oferta creada con éxito"];
        }
        return ["message" => "Error al crear la oferta"];
    }

    public function update($id, $data) {
        $query = "UPDATE " . $this->table . " 
                  SET titulo = :titulo, descripcion = :descripcion, ubicacion = :ubicacion,
                      salario = :salario, tipo_contrato = :tipo_contrato, fecha_cierre = :fecha_cierre
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':titulo', $data['titulo']);
        $stmt->bindParam(':descripcion', $data['descripcion']);
        $stmt->bindParam(':ubicacion', $data['ubicacion']);
        $stmt->bindParam(':salario', $data['salario']);
        $stmt->bindParam(':tipo_contrato', $data['tipo_contrato']);
        $stmt->bindParam(':fecha_cierre', $data['fecha_cierre']);
        $stmt->bindParam(':id', $id);
        if ($stmt->execute()) {
            return ["message" => "Oferta actualizada"];
        }
        return ["message" => "Error al actualizar la oferta"];
    }

    public function deactivate($id) {
        $query = "UPDATE " . $this->table . " SET estado = 'Baja' WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$id])) {
            return ["message" => "Oferta desactivada"];
        }
        return ["message" => "Error al desactivar la oferta"];
    }
}
?>
<?php