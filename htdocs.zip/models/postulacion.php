<?php
class Postulacion {
    private $conn;
    private $tabla = "Postulacion";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function crearPostulacion($data) {
        $query = "INSERT INTO " . $this->tabla . " (candidato_id, oferta_laboral_id, comentario)
                  VALUES (:candidato_id, :oferta_laboral_id, :comentario)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':candidato_id', $data['candidato_id']);
        $stmt->bindParam(':oferta_laboral_id', $data['oferta_laboral_id']);
        $comentario = isset($data['comentario']) ? $data['comentario'] : null;
        $stmt->bindParam(':comentario', $comentario);
        if ($stmt->execute()) {
            return ["message" => "Postulación registrada"];
        }
        return ["message" => "Error al registrar postulación"];
    }

    public function actualizarEstado($id, $data) {
        $query = "UPDATE " . $this->tabla . " 
                  SET estado_postulacion = :estado_postulacion, comentario = :comentario 
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':estado_postulacion', $data['estado_postulacion']);
        $stmt->bindParam(':comentario', $data['comentario']);
        $stmt->bindParam(':id', $id);
        if ($stmt->execute()) {
            return ["message" => "Estado actualizado"];
        }
        return ["message" => "Error al actualizar estado"];
    }

    public function verEstado($id) {
        $query = "SELECT estado_postulacion, comentario FROM " . $this->tabla . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPostulacionesPorOferta($id_oferta) {
        $query = "SELECT * FROM " . $this->tabla . " WHERE oferta_laboral_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id_oferta]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
